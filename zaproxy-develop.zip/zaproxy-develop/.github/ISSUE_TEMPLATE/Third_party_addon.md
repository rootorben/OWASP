---
name: '3rd party add-on '
about: Tell us about a 3rd party add-on that we should add or update in the ZAP Marketplace
labels: marketplace

---

**Add-on repo**
The URL of the repository for the add-on.

**Your contact details**
Email, twitter, whatever works for you.

**Are you one of the authors**
Yes / No

**Licence**
If not clearly stated in the repo.

**Build instructions**
If not in the repo.

**Link to more information**

**Twitter handle for tool or author(s)**
Will be used in the announcement tweet from @zaproxy

**Promote to Beta or Release?**
Note that all new add-ons start at Alpha status.
<!--
Refer to the following pages for the guidelines of each status:
https://github.com/zaproxy/zap-extensions/wiki/AddOnsAlpha
https://github.com/zaproxy/zap-extensions/wiki/AddOnsBeta
https://github.com/zaproxy/zap-extensions/wiki/AddOnsRelease
-->

**Anything else we should know**
