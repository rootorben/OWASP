<?php

class AboutController extends JControl
{
	function Start()
	{
		$this->Present();
	}
}

?>