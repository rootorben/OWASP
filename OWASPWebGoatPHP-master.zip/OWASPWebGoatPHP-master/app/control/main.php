<?php
class MainController extends JControl
{
	function Start()
	{
		return $this->Present ();

	}
}
?>