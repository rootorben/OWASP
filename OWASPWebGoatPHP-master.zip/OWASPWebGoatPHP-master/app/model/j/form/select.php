<?php
/**
 * Alias for jFormDropdown
 * @author abiusx
 *
 */
class jFormSelect extends jFormDropdown {}