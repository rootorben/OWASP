<?php
namespace jf;
class MainController extends Controller
{
    function Start ()
    {
        return $this->Present();
    }
}
?>