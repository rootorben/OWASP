<?php
class PluginMainTest extends JTestSuite
{
	function __construct()
	{
		$this->add("jf/test/plugin/jalali");
	}
}