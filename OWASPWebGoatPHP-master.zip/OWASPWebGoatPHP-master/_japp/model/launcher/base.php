<?php
namespace jf;

class BaseLauncher extends Model
{
	protected $Result=null;
	function Result()
	{
		return $this->Result;
	}

}