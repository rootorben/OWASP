<?php
namespace jf;
abstract class Plugin extends Model 
{
    
}

?>