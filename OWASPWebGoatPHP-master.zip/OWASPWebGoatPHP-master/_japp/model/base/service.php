<?php
namespace jf;
abstract class Service  
{
    abstract function Execute($Params);
    
}

?>