<?php
namespace jf;
/**
 * jframework mariadb adapter
 * @version 1.00
 */
class DB_mariadb extends DB_pdo_mysql
{

}


/**
 * jframework mariadb prepared statements class
 * @version 1.00
 */
class DB_Statement_mariadb extends DB_Statement_pdo_mysql
{

}
?>