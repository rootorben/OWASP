<?php
class JTest extends \jf\Test{}
class JTestSuite extends \jf\TestSuite{}
abstract class JDbTest extends \jf\DbTest{}
