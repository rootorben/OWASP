<?php
class ServiceOutput_array extends BaseServiceOutputFormatter 
{
	function Format($Data,$Request)
	{
		return $Data;
	}
	
}
?>