<?php
class ServiceInput_array extends BaseServiceInputFormatter 
{
	function Format($Data)
	{
		return $Data;
	}
	
}
?>