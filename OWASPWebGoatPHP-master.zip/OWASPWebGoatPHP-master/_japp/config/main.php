<?php
namespace jf;

const version="4.21";

const WHOAMI="jframework 4.21";





?>